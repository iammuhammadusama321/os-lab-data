#include<iostream>
using namespace std;
int main(){

    int l, w, a;
    cout<<"Enter Lenght: ";
    cin>>l;
    cout<<"Enter Width: ";
    cin>>w;
    a= l*w;
    cout<<"Area is: "<<a<<"\n";
}