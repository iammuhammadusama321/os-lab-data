#include <iostream>
using namespace std;
int main() {
    const int SIZE = 5;
    int numbers[SIZE];
    int count = 0;

    // Input loop
    cout << "Enter up to 5 integers (terminate with -99):" << endl;
    for (int i = 0; i < SIZE; i++) {
        int input;
        cin >> input;
        if (input == -99) break;  // Terminate on -99
        numbers[count++] = input;  // Store input
    }
    // Bubble Sort
    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - 1 - i; j++) {
            if (numbers[j] > numbers[j + 1]) {
                // Swap
                int temp = numbers[j];
                numbers[j] = numbers[j + 1];
                numbers[j + 1] = temp;
            }
        }
    }
    // Display results
    cout << "The entered sequence is: ";
    for (int i = 0; i < count; i++) {
        cout << numbers[i] << " ";
    }
    cout << endl;

    cout << "Updated sequence is: ";
    for (int i = 0; i < count; i++) {
        cout << numbers[i] << " ";
    }
    cout << endl;
    return 0;
}
