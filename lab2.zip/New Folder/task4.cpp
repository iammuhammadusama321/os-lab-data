#include <iostream>
using namespace std;
void checkPrimeNumber() {

    int num;
    cout << "Enter the number: ";
    cin >> num;

    if (num < 2) {
        cout << "Output: Not Prime" << endl;
        return;
    }
    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) {
            cout << "Output: Not Prime" << endl;
            return;
        }
    }
    cout << "Output: Prime" << endl;
}
int main() {
    checkPrimeNumber();
    return 0;
}
