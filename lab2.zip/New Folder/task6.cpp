#include <iostream>
using namespace std;
int main() {
    
    int size;
    cout << "Enter the number of elements in the array: ";
    cin >> size;

    //check size
    if (size < 2) {
        cout << "Please enter at least two elements." << endl;
        return 1;
    }

    //allocate memory
    int* arr = new int[size]; // dynamic array allocation

    //input
    cout << "Enter the array elements: ";
    for (int i = 0; i < size; ++i) {
        cin >> arr[i]; // Assign values
    }

    int min1, min2;
    // find the first two distinct elements to initialize min1 and min2
    if (arr[0] < arr[1]) {
        min1 = arr[0];
        min2 = arr[1];
    } else {
        min1 = arr[1];
        min2 = arr[0];
    }
    //loop for iteration
    for (int i = 2; i < size; ++i) {
        if (arr[i] < min1) {
            min2 = min1;  
            min1 = arr[i]; 
        } else if (arr[i] < min2 && arr[i] != min1) {
            min2 = arr[i]; 
        }
    }
    // Check if second minimum was found
    if (min1 == min2) {
        cout << "No second minimum found (all elements may be equal)." << endl;
    } else {
        cout << "The second minimum number is: " << min2 << endl;
    }
    // Deallocate memory 
    delete[] arr;

    return 0;
}
