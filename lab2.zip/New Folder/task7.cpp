#include <iostream>
#include <string>

using namespace std;

struct Employee {
    int id;
    string name;
    int age;
    float pay;
};

int main() {
    Employee emp;

    cout << "Enter employee ID: ";
    cin >> emp.id;
    cout << "Enter employee name: ";
    cin.ignore();
    getline(cin, emp.name);
    cout << "Enter employee age: ";
    cin >> emp.age;
    cout << "Enter employee pay: ";
    cin >> emp.pay;

    cout << "\nEmployee Information:\n";
    cout << "ID: " << emp.id << endl;
    cout << "Name: " << emp.name << endl;
    cout << "Age: " << emp.age << endl;
    cout << "Pay: " << emp.pay << endl;

    return 0;
}
