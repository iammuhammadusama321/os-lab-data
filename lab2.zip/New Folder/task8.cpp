#include <iostream>
#include <fstream>
#include <string>

using namespace std;

struct Employee {
    string id, name, position;
    char gender;
    int experience;
    float salary;
};

//prototypes

void addEmployee(Employee* empArray, int& empCount);
void findEmployeeByID(const Employee* empArray, int empCount);
void displayAllEmployees(const Employee* empArray, int empCount);
void displayLowSalaryEmployees(const Employee* empArray, int empCount);
void writeToFile(const Employee* empArray, int empCount);

int main() {
    Employee empArray[100];
    int empCount = 0;

    ifstream inputFile("task1.txt");
    while (inputFile >> empArray[empCount].id >> empArray[empCount].name 
                     >> empArray[empCount].gender >> empArray[empCount].position 
                     >> empArray[empCount].experience >> empArray[empCount].salary) {
        empCount++;
    }

    int option;
    do {
        cout << "\n===== EMPLOYEE MENU =====\n";
        cout << "1. Add Employee\n2. Search by ID\n3. Display All\n"
             << "4. Display Low Salary Employees\n5. Save & Exit\nSelect an option: ";
        cin >> option;

        switch (option) {
            case 1: addEmployee(empArray, empCount); break;
            case 2: findEmployeeByID(empArray, empCount); break;
            case 3: displayAllEmployees(empArray, empCount); break;
            case 4: displayLowSalaryEmployees(empArray, empCount); break;
            case 5: writeToFile(empArray, empCount); break;
            default: cout << "Please select a valid option.\n";
        }
    } while (option != 5);

    return 0;
}

void addEmployee(Employee* empArray, int& empCount) {
    if (empCount < 100) {
        cout << "Enter ID, Name, Gender (m/f), Position, Experience, Salary: ";
        cin >> empArray[empCount].id >> empArray[empCount].name >> empArray[empCount].gender
            >> empArray[empCount].position >> empArray[empCount].experience >> empArray[empCount].salary;
        empCount++;
        cout << "Employee added successfully.\n";
    } else {
        cout << "Maximum employee limit reached.\n";
    }
}

void findEmployeeByID(const Employee* empArray, int empCount) {
    string id;
    cout << "Enter the ID to search: ";
    cin >> id;

    for (int i = 0; i < empCount; i++) {
        if (empArray[i].id == id) {
            cout << empArray[i].id << " " << empArray[i].name << " "
                 << empArray[i].gender << " " << empArray[i].position << " "
                 << empArray[i].experience << " " << empArray[i].salary << endl;
            return;
        }
    }
    cout << "No employee found with that ID.\n";
}

void displayAllEmployees(const Employee* empArray, int empCount) {
    for (int i = 0; i < empCount; i++) {
        cout << empArray[i].id << " " << empArray[i].name << " "
             << empArray[i].gender << " " << empArray[i].position << " "
             << empArray[i].experience << " " << empArray[i].salary << endl;
    }
}

void displayLowSalaryEmployees(const Employee* empArray, int empCount) {
    cout << "Employees earning less than 20,000:\n";
    for (int i = 0; i < empCount; i++) {
        if (empArray[i].salary < 20000) {
            cout << empArray[i].id << " " << empArray[i].name << " "
                 << empArray[i].gender << " " << empArray[i].position << " "
                 << empArray[i].experience << " " << empArray[i].salary << endl;
        }
    }
}

void writeToFile(const Employee* empArray, int empCount) {
    ofstream outputFile("task1.txt");
    for (int i = 0; i < empCount; i++) {
        outputFile << empArray[i].id << " " << empArray[i].name << " "
                   << empArray[i].gender << " " << empArray[i].position << " "
                   << empArray[i].experience << " " << empArray[i].salary << endl;
    }
    cout << "Data successfully saved to file.\n";
}

